/*             __                         __
    __  ______/ /___  _________  ____    / /_  ____  ____
   / / / / __  / __ \/ ___/ __ \/ __ \  / __ \/ __ \/ __ \
  / /_/ / /_/ / /_/ / /__/ /_/ / /_/ / / / / / /_/ / /_/ /
  \__,_/\__,_/ .___/\___/ .___/ .___(_)_/ /_/ .___/ .___/
            /_/        /_/   /_/           /_/   /_/     

// Version - 1.0
// License - Identifier: MIT
// GitHub - https://github.com/googolenergy
// For documentation refer https://github.com/googolenergy/udpcpp.hpp/wiki
*/

#include "include/udpcpp.hpp"

int main() {
    /*
    * SEND =>
    
    while (true) {
        udpSend(6900, "hello! world");
        Sleep(1000);
    }

    * READ =>
    
    while (true) {
        std::cout << udpRead(6900) << "\n";
        Sleep(1000);
    }
    */

    return 0;
}
